
const navToggle = document.querySelector('.nav-toggle');
const nav = document.querySelector('.nav');
if (navToggle && nav) {
  navToggle.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    navToggle.setAttribute('aria-expanded', String(open));
  });
}
document.querySelectorAll('.nav a').forEach(a => a.addEventListener('click', () => nav?.classList.remove('open')));

const modal = document.getElementById('resource-modal');
const modalImage = document.getElementById('modal-image');
const modalTitle = document.getElementById('modal-title');
document.addEventListener('click', (event) => {
  const viewer = event.target.closest('[data-view-image]');
  if (viewer && modal) {
    modalImage.src = viewer.dataset.viewImage;
    modalImage.alt = viewer.dataset.title || 'Handout preview';
    modalTitle.textContent = viewer.dataset.title || 'Handout preview';
    modal.classList.add('open');
    document.body.style.overflow = 'hidden';
  }
  if (event.target.matches('.modal-close') || event.target === modal) closeModal();
});
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });
function closeModal(){
  if (!modal) return;
  modal.classList.remove('open');
  document.body.style.overflow = '';
}

const search = document.getElementById('resource-search');
const audience = document.getElementById('audience-filter');
const topic = document.getElementById('topic-filter');
const cards = [...document.querySelectorAll('.resource-card')];

function filterResources() {
  if (!cards.length) return;
  const q = (search?.value || '').toLowerCase().trim();
  const a = audience?.value || 'all';
  const t = topic?.value || 'all';
  let shown = 0;
  cards.forEach(card => {
    const haystack = card.textContent.toLowerCase();
    const match = (!q || haystack.includes(q))
      && (a === 'all' || card.dataset.audience.includes(a))
      && (t === 'all' || card.dataset.topic.includes(t));
    card.classList.toggle('hidden', !match);
    if (match) shown++;
  });
  const count = document.getElementById('resource-count');
  if (count) count.textContent = `${shown} resource${shown === 1 ? '' : 's'}`;
}
[search, audience, topic].forEach(el => el?.addEventListener('input', filterResources));
filterResources();
