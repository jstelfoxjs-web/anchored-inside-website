# Anchored Inside Website — Version 2

This is a complete static HTML website ready for a manual Netlify deployment.

## Included pages
- Home
- About Me
- Anchored Inside Philosophy
- Searchable Resource Library
- Handout Upload Guide
- Contact Form (Netlify Forms)
- Resource Disclaimer
- Privacy

## Publish on Netlify
1. Keep all files and folders together.
2. Upload the complete `anchored-inside-website-v2` folder or ZIP to Netlify.
3. Netlify should use `index.html` automatically.

## Add resources
See `upload-guide.html`. Put new files in:
`assets/handouts/`

Then duplicate one resource card in `resources.html`, update the file path and information, and redeploy.

## Before public launch
Replace:
- sample email and phone number
- appointment links
- Psychology Today link
- office information
- final privacy and disclaimer language
- any resource images that you do not have permission to publish publicly

Important: Some starter handout images were supplied for this build. Confirm that you own them or have permission to distribute them before making the website public.
